import os
import shutil
import requests
import subprocess
import sys
from zipfile import ZipFile

def download_file(url, file_path):
    try:
        with requests.get(url, stream=True) as response:
            response.raise_for_status()
            content_length = response.headers.get('content-length')
            if content_length is None:
                print("Warning: Unable to determine file size.")
                return
            total_size = int(content_length)
            downloaded = 0
            with open(file_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
                    downloaded += len(chunk)
                    progress = min(100, int(downloaded / total_size * 100))
                    print(f"\rDownloading: {'#' * (progress // 2)}{' ' * ((100 - progress) // 2)} {progress}%", end='', flush=True)
    except Exception as e:
        print(f"Error downloading file: {e}")

def extract_zip(zip_file, destination):
    with ZipFile(zip_file, 'r') as zip_ref:
        zip_ref.extractall(destination)

def main():
    print("Fixing Krampus / RO-EXEC...")
    download_url = "https://www.dropbox.com/scl/fi/adyzd5q6oayewpa8hzjz5/version-aa463de288b941f3-1.zip?rlkey=efhzabhqu4ke0n6b178w6xprb&dl=1"
    download_path = os.path.join(os.getcwd(), 'version-aa463de288b941f3.zip')  # Use absolute path
    destination_path = os.path.join(os.getcwd(), 'version-aa463de288b941f3')

    try:
        download_file(download_url, download_path)
        if not os.path.exists(download_path):
            print(f"Error: Downloaded file '{download_path}' not found.")
            sys.exit(1)
        extract_zip(download_path, destination_path)
        os.remove(download_path)  # Delete the ZIP file after extraction
        print("\nFixing Shortcut...")
        subprocess.run(["cscript", "//nologo", "applocation\\Shortcut.vbs"])
        print("Fixed Shortcut Location")
        print("Running Applocation.vbs...")
        subprocess.run(["cscript", "//nologo", "applocation\\Applocation.vbs"])
        print("Try launching Roblox (Krampus fixed).")
        print("Need help? Contact scriptx0166 on Discord.")

    except Exception as e:
        print(f"An error occurred: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
